namespace HeroInventoryApp
{
    public class Item
    {
        public string Name { get; private set; }
        public string Type { get; private set; }
        public int Price { get; private set; }
        public bool IsIdentified { get; private set; }

        public Item(string name, string type, int price, bool identified)
        {
            Name = name;
            Type = type;
            Price = price;
            IsIdentified = identified;
        }

        public void Identify()
        {
            if (!IsIdentified)
            {
                Name = Name.Replace("Неопознанный", "Опознанный");
                Type = "Обычный предмет";
                IsIdentified = true;
            }
        }
    }
}
