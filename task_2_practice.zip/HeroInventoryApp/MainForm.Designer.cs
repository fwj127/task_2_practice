using System;
using System.Windows.Forms;

namespace HeroInventoryApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        public System.Windows.Forms.ListBox listInventory;
        public System.Windows.Forms.Label lblWallet;
        public System.Windows.Forms.Button btnAnalyze;
        public System.Windows.Forms.Button btnSellTrash;
        public System.Windows.Forms.GroupBox groupStats;
        public System.Windows.Forms.Label lblTotalItems;
        public System.Windows.Forms.Label lblTotalPrice;
        public System.Windows.Forms.Label lblMostValuable;
        public System.Windows.Forms.ComboBox comboMerchant;
        public System.Windows.Forms.Button btnBuy;
        public System.Windows.Forms.Label labelTitle;

        private void InitializeComponent()
        {
            this.labelTitle = new Label(){Text="Инвентарь героя", AutoSize=true, Top=10, Left=10};
            this.listInventory = new ListBox(){Top=40, Left=10, Width=260, Height=120};
            this.lblWallet = new Label(){Text="Кошелёк: 0", AutoSize=true, Top=170, Left=10};
            this.btnAnalyze = new Button(){Text="Анализировать", Top=200, Left=10};
            this.btnAnalyze.Click+=btnAnalyze_Click;
            this.btnSellTrash = new Button(){Text="Продать хлам (<50)", Top=240, Left=10, Width=260};
            this.btnSellTrash.Click+=btnSellTrash_Click;
            this.groupStats = new GroupBox(){Text="Статистика", Top=280, Left=10, Width=266, Height=100};
            this.lblTotalItems = new Label(){Text="Всего предметов: 0", AutoSize=true, Top=20, Left=10};
            this.lblTotalPrice = new Label(){Text="Общая стоимость: 0", AutoSize=true, Top=45, Left=10};
            this.lblMostValuable = new Label(){Text="Самый ценный: ?", AutoSize=true, Top=70, Left=10};
            groupStats.Controls.AddRange(new Control[]{lblTotalItems, lblTotalPrice, lblMostValuable});
            this.comboMerchant = new ComboBox(){Top=390, Left=10, Width=260};
            this.btnBuy = new Button(){Text="Купить", Top=430, Left=10};
            this.btnBuy.Click+=btnBuy_Click;

            this.Controls.AddRange(new Control[]{labelTitle, listInventory, lblWallet, btnAnalyze, btnSellTrash, groupStats, comboMerchant, btnBuy});
            this.Text="Hero Inventory";
            this.ClientSize = new System.Drawing.Size(300,480);
        }

        protected override void Dispose(bool disposing)
        {
            if(disposing && components!=null) components.Dispose();
            base.Dispose(disposing);
        }
    }
}
