using System;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;

namespace HeroInventoryApp
{
    public partial class MainForm : Form
    {
        private List<Item> inventory = new();
        private int wallet = 0;
        private Item[] merchantItems;

        public MainForm()
        {
            InitializeComponent();
            InitData();
            RefreshInventoryList();
            RefreshWallet();
            RefreshStats();
        }

        private void InitData()
        {
            merchantItems = new Item[]
            {
                new Item("Меч", "Оружие", 1000, true),
                new Item("Зелье лечения", "Расходник", 50, true),
                new Item("Щит", "Броня", 200, true)
            };

            comboMerchant.Items.AddRange(
                merchantItems.Select(i => $"{i.Name} ({i.Price})").ToArray());

            if (comboMerchant.Items.Count > 0) comboMerchant.SelectedIndex = 0;

            inventory.Add(new Item("Неопознанный предмет", "?", 30, false));
            inventory.Add(new Item("Неопознанный меч", "?", 120, false));
            inventory.Add(new Item("Неопознанный артефакт", "?", 2000, false));
            inventory.Add(new Item("Неопознанный хлам", "?", 10, false));
        }

        private void btnAnalyze_Click(object sender, EventArgs e)
        {
            try
            {
                if (inventory.Count == 0)
                    throw new Exception("Инвентарь пуст!");

                int count = 0;
                int sum = 0;
                Item maxItem = inventory[0];

                foreach (Item item in inventory)
                {
                    count++;
                    sum += item.Price;
                    if (item.Price > maxItem.Price)
                        maxItem = item;
                }

                lblTotalItems.Text = $"Всего предметов: {count}";
                lblTotalPrice.Text = $"Общая стоимость: {sum}";
                lblMostValuable.Text = $"Самый ценный: {maxItem.Name} ({maxItem.Price})";

                foreach (Item item in inventory) item.Identify();
                RefreshInventoryList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка анализа:\n{ex.Message}", "Exception",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSellTrash_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listInventory.SelectedIndex;
                if (index < 0)
                    throw new Exception("Предмет не выбран!");

                Item selectedItem = inventory[index];

                if (selectedItem.Price >= 50)
                {
                    MessageBox.Show("Этот предмет не считается хламом!", "Торговец",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                wallet += selectedItem.Price;
                inventory.RemoveAt(index);

                RefreshInventoryList();
                RefreshWallet();
                RefreshStats();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка продажи:\n{ex.Message}", "Exception",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuy_Click(object sender, EventArgs e)
        {
            try
            {
                int mIndex = comboMerchant.SelectedIndex;
                if (mIndex < 0)
                    throw new Exception("Товар не выбран!");

                Item merchantItem = merchantItems[mIndex];
                if (wallet < merchantItem.Price)
                    throw new InvalidOperationException("Не хватает золота!");

                wallet -= merchantItem.Price;
                inventory.Add(new Item(merchantItem.Name, merchantItem.Type, merchantItem.Price, true));

                RefreshInventoryList();
                RefreshWallet();
                RefreshStats();
            }
            catch (InvalidOperationException)
            {
                MessageBox.Show("Не хватает золота!", "Торговец",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка покупки:\n{ex.Message}", "Exception",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshInventoryList()
        {
            listInventory.Items.Clear();
            foreach (var i in inventory)
                listInventory.Items.Add($"{i.Name} ({i.Price})");
        }

        private void RefreshWallet() => lblWallet.Text = $"Кошелёк: {wallet}";

        private void RefreshStats()
        {
            lblTotalItems.Text = $"Всего предметов: {inventory.Count}";
            lblTotalPrice.Text = $"Общая стоимость: {inventory.Sum(i => i.Price)}";
            lblMostValuable.Text = "Самый ценный: ?";
        }
    }
}
